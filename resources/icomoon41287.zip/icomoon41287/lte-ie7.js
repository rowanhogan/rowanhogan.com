/* Use this script if you need to support IE 7 and IE 6. */

window.onload = function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'icomoon\'">' + entity + '</span>' + html;
	}
	var icons = {
			'icon-light-bulb' : '&#x21;',
			'icon-painting' : '&#x22;',
			'icon-keyboard' : '&#x23;',
			'icon-globe' : '&#x24;',
			'icon-cloud' : '&#x25;',
			'icon-mobile' : '&#x26;',
			'icon-browser' : '&#x27;',
			'icon-dribbble' : '&#x28;',
			'icon-github' : '&#x29;',
			'icon-twitter' : '&#x2a;',
			'icon-lastfm' : '&#x2b;',
			'icon-linkedin' : '&#x2c;',
			'icon-google-plus' : '&#x2d;',
			'icon-forrst' : '&#x2e;'
		},
		els = document.getElementsByTagName('*'),
		i, attr, html, c, el;
	for (i = 0; i < els.length; i += 1) {
		el = els[i];
		attr = el.getAttribute('data-icon');
		if (attr) {
			addIcon(el, attr);
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c) {
			addIcon(el, icons[c[0]]);
		}
	}
};